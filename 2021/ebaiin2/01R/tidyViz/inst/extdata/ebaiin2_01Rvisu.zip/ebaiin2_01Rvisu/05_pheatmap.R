library(pheatmap)
data("fruits", package = "tidyViz")

pheatmap(fruits)

pheatmap(fruits[, -(1:2)])

?pheatmap

pheatmap(
  fruits[, -(1:2)],
  cluster_rows = FALSE,
  scale = "column",
  show_rownames = FALSE,
  cellwidth = 10
)

colfun <- colorRampPalette(
  c("darkorchid", 
    "white", 
    "limegreen"))

pheatmap(
  fruits[, -(1:2)],
  cluster_rows = FALSE,
  scale = "column",
  show_rownames = FALSE,
  cellwidth = 10,
  color = colfun(50)
)

## Ajouter des informations qualitatives
colfun <- colorRampPalette(
  c("darkorchid", 
    "white", 
    "limegreen"))

fruitsDF <- data.frame(
  fruits[,-1], 
  row.names = make.unique(fruits$nom))

annotLignes <- fruitsDF[, "groupe", 
                        drop = FALSE]

pheatmap(
  fruitsDF[, -1],
  cluster_rows = FALSE,
  scale = "column",
  show_rownames = FALSE,
  cellwidth = 10,
  color = colfun(20), 
  annotation_row = annotLignes
)

## Faire une heatmap sur des données binaires
M <- matrix(sample(0:1, 100, replace = TRUE), 10, 10)
pheatmap(
  M, 
  color = c("lightblue", "steelblue"),
  border = "white",
  clustering_distance_rows = "binary",
  clustering_distance_cols = "binary", 
  legend_breaks = seq(0, 1, length = 5), 
  legend_labels = c("", "0", "", "1", ""))

