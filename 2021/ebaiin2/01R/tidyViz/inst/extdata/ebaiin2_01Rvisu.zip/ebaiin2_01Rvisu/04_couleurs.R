library(RColorBrewer)

data("fruits", package = "tidyViz")

# Barplot couleurs entières
barplot(rep(1,8), col = 1:8)

colors()
sample(colors(), 7)

## Exercice : diagramme en bâtons
barplot(c(1:5, 1:5), col = c("steelblue", "tomato"))


display.brewer.all()
brewer.pal(n = 3, name = "Set3")


pal <- brewer.pal(n = 7, name = "Set1")
barplot(rep(1, 7), 
        col = pal, 
        axes = FALSE, 
        border = NA)


# ColorRampPalette
colfun <- colorRampPalette(c("darkorchid", "black", "limegreen"))
barplot(rep(1, 30), col = colfun(30), axes = F, border = NA)

# Exercice
colfun <- colorRampPalette(
  c("dodgerblue2", "green", "red"))
barplot(rep(1, 100),
        col = colfun(100),
        axes = F, border = NA)