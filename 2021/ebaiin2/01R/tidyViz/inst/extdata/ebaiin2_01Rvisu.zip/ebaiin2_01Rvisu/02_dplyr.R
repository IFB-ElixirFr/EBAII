library(dplyr) # ou require(dplyr)

# Pour installer tidyViz
# remotes::install_github(
#   "IFB-ElixirFr/EBAII",
#   subdir = "2021/ebaiin2/01R/tidyViz")

# Chargement des données fruits
data("fruits", package = "tidyViz")
View(fruits) # Pour visualiser les données

# mutate
fruits2 <- fruits %>% 
  mutate(Sucres_ratio = Sucres / 100)

head(fruits2[, "Sucres_ratio"])

# select
fruits %>% 
  select(
    Energie,
    Sucres,
    Lipides,
    Proteines)

# arrange
fruits %>% 
  select(Energie, Sucres, Fibres) %>%
  arrange(desc(Fibres))

# filter
fruits %>% 
  filter(Sucres > 60)

# group_by
fruits %>% group_by(groupe)

# group_by + summarize
fruits %>% 
  group_by(groupe, Proteines > 0.8) %>%
  summarize(SucreMoyen = mean(Sucres),
            FibresMoyennes = mean(Fibres)) %>%
  ungroup()

fruits %>% 
  summarize(SucreMoyen = mean(Sucres),
            FibresMoyennes = mean(Fibres))

# Calculer l’énergie moyenne, 
# la teneur en sucres médiane et 
# le maximum de la teneur en Fibres 
# par groupe de fruits et trier le tout 
# par ordre décroissant du maximum de 
# la teneur en Fibres !
fruits %>% 
  group_by(groupe) %>%
  summarize(
    EnergieMoyenne = mean(Energie),
    SucresMediane = median(Sucres),
    FibresMax = max(Fibres)) %>%
  arrange(desc(FibresMax))
