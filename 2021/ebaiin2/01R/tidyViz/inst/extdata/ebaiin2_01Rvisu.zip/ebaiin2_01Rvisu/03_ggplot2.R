library(ggplot2)
data("fruits", package = "tidyViz")

# Diagrammes en bâtons
barplot(table(fruits$groupe))

ggplot(data = fruits, aes(x = groupe, fill = groupe)) +
  geom_bar()

# Exercice de diagrammes en bâtons
ggplot(fruits, 
       aes(x = Sucres > 10, 
           fill = Sucres > 10)) +
  geom_bar()
# geom_bar
ggplot(fruits, aes(cut(Eau, c(0, 84.2, 100)))) + 
  geom_bar(fill = "steelblue")

ggplot(fruits, aes(Eau > 84.2)) + 
  geom_bar(fill = "steelblue")

ggplot(data = fruits, mapping = aes(x = cut(Eau, c(0, 84.2, 100)))) + 
  geom_bar(fill = "steelblue")

# geom_col
dat.count <- fruits %>% 
  group_by(groupe) %>%
  summarize(Csup10 = sum(VitamineC >= 10))

ggplot(data = dat.count, aes(x = groupe, y = Csup10)) +
  geom_col()

# Pour avoir des pourcentages
dat.count.perc <- fruits %>% 
  group_by(groupe) %>%
  summarize(Csup10perc = 100 * mean(VitamineC >= 10))

ggplot(data = dat.count.perc, aes(x = groupe, y = Csup10perc)) +
  geom_col()

# Modification avec breaks
ggplot(fruits, aes(Sucres)) + 
  geom_histogram(breaks = seq(0, 75, 5))

# Modification des couleurs de remplissage
# et de contour
ggplot(fruits, aes(Sucres)) + 
  geom_histogram(breaks = seq(0, 75, 5),
                 fill = "steelblue",
                 color = "white")

# Boxplot
ggplot(data=fruits, aes(x = Sucres)) + 
  geom_boxplot()

# Boxplot pour les groupes
ggplot(data=fruits, aes(x=Sucres, y=groupe)) + 
  geom_boxplot()

# Avec les points en plus
ggplot(data=fruits, aes(x=Sucres, y=groupe)) + 
  geom_boxplot() +
  geom_point()

# Avec les points en plus avec un petit shake aléatoire
ggplot(data=fruits, aes(x=Sucres, y=groupe)) + 
  geom_boxplot() +
  geom_jitter()

#Diagramme en violons
ggplot(data=fruits, aes(x = groupe, y = Sucres)) + 
  geom_violin()
# Diagramme en violons en couleurs
ggplot(fruits, 
       aes(x = Fibres > 1.5, 
           y = Proteines, 
           fill = Fibres > 1.5)) + 
  geom_violin()


# Thème
ggplot(fruits, aes(y = Fibres)) + 
  geom_boxplot() + 
  theme_classic()

# Exemple : labs
ggplot(fruits, aes(y = Fibres)) + 
  geom_boxplot() + 
  theme_classic() + 
  labs(title = "Boxplot",
       y = "Teneur en fibres")

# Exemple : theme
ggplot(fruits, aes(x = groupe, y = Fibres, color = groupe)) + 
  geom_boxplot() + 
  theme_classic() + 
  labs(title = "Boxplot",
       y = "Teneur en fibres") + 
  theme(legend.position = "bottom",
        axis.title.x = element_text(face = "bold"))

# Nuage des points
ggplot(fruits, aes(x = Phosphore, y = Calcium, size = Magnesium)) + 
  geom_point()

ggplot(fruits, 
       aes(x = Phosphore, y = Calcium, 
           color = Magnesium)) + 
  geom_point() + 
  theme(legend.position = "bottom")

ggplot(fruits, 
       aes(x = Phosphore, y = Calcium)) + 
  geom_point(color = "limegreen")

ggplot(fruits, 
       aes(x = Phosphore, y = Calcium)) + 
  geom_point(color = "limegreen")

## Exercice
ggplot(fruits,
       aes(x = Sucres, 
           y = Proteines, 
           size = Magnesium, 
           color = groupe)) + 
  geom_point() + 
  labs(title = "Fruits",
      x = "Sucres (g/100 g)", 
      y = "Protéines, N x 6.25 (g/100 g)",
      size = "Magnésium\n(mg/100 g)",
      color = "Groupe") + 
  theme_bw()

## Alpha
ggplot(fruits, 
       aes(x = Phosphore, 
           y = Calcium, 
           color = groupe)) + 
  geom_point(alpha = 0.5, 
             size = 2) + 
  theme_bw() + 
  theme(legend.position = 
          "bottom")

## Personnaliser les échelles"
ggplot(fruits, 
       aes(Phosphore, 
           Calcium)) + 
  geom_point(color = "white") + 
  scale_x_log10() + 
  scale_y_log10() + 
  labs(x = "log10(Phosphore)",
       y = "log10(Calcium)") + 
  theme_dark()

## Sauvegarder des graphes
g <- ggplot(fruits, 
            aes(Phosphore, 
                Calcium)) + 
  geom_point(color = "white") + 
  scale_x_log10() + 
  scale_y_log10() + 
  labs(x = "log10(Phosphore)",
       y = "log10(Calcium)") + 
  theme_dark()

ggsave(filename = "sauve_dark.png", plot = g)
ggsave(filename = "sauve_dark.pdf", plot = g)

## Ajouter une densité théorique sur un histogramme...
## c'est pas facile : 

# Sur des données simulées :
dat <- data.frame(x = rnorm(200))

# Il faut utiliser la "densité" et pas les comptages
ggplot(dat, aes(x)) + 
  geom_histogram(aes(y = ..density..)) + 
  stat_function(fun = dnorm)

# En plus joli
ggplot(dat, aes(x)) + 
  geom_histogram(
    aes(y = ..density..),
    color = "white", 
    fill = "steelblue",
    bins = 20) + 
  stat_function(fun = dnorm, size = 1) + 
  theme_light() + 
  labs(x = "Valeurs de la variable",
       y = "Densité")




